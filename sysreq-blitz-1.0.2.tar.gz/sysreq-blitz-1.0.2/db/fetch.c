#include <sys/syscall.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <apue.h>
#include <apue_db.h>

int
main(int argc, char *argv[]){
	DBHANDLE db;
	char key[11];
	char data[1024];
	int i;
	if(argc!=2)return 1;
	if((db = db_open("db4", O_RDONLY, FILE_MODE)) == 
NULL)
		err_sys("db_open error");
	for(i=0; i<1024; i++)data[i]=0;
	sprintf(key,"%s", argv[1]);		
	strncat(data, db_fetch(db, argv[1]), 1020);
	write(0, data, strlen(data));
	printf("\n");
	db_close(db);
	return 0;
};
