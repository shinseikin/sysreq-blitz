#include <curses.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include "apue.h"
#include "apue_db.h"

void shoe(void);
void datarec(char *);

int
main(void){
	int escape;
	char grabbed;
	SCREEN *screen;
	WINDOW *win;
	FILE *input;
	FILE *output;
	FILE *keyfile;
	char key[11];
	DBHANDLE db;
	int display;

	screen = newterm(NULL, input, output);
	win = initscr();
	nodelay(win, TRUE);

	if ( (keyfile=fopen("KEYS.TXT", "r+"))==NULL)
		err_sys("keyfile opening failed");
	if((db=db_open("db4", O_RDWR, FILE_MODE))==NULL)
		err_sys("db_open failed");
	
	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			if(display==0)display=1;
			else display=0;
		}
				/* output rejuncture flip */
		if(display==0){
			shoe();
		} else {
			datarec(key);
		}
		wrefresh(win);
	}
	fclose(keyfile);
	db_close(db);
	endwin();
	return 0;
}

void
shoe(){
	return;
}

void
datarec(char *rec){
	return;
}
