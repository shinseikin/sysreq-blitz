#include <curses.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include "apue.h"
#include "apue_db.h"

/*int loadkeys(void);
int savekeys(void);

struct diskdata {
	storage[25][11]
};
*/

struct dat{
	WINDOW* mywin;
	DBHANDLE mydb;
	char keylist[25][11];
	int tos;
};


void shoe(struct dat*, int);
int newrec (struct dat*);
int editrec(WINDOW*, DBHANDLE, char*);
int datarec(WINDOW*, DBHANDLE, char*);
