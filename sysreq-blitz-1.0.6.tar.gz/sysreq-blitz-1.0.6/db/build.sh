#!/bin/sh
touch KEYS.TXT
cc main.c -o blitz -L. -L../lib -lapue_db -lapue -lcurses -I. -I../include
cc creatdb.c -o creatdb -L. -L../lib -lapue_db -lapue -I. -I../include

