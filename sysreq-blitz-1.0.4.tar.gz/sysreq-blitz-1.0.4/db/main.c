#include <curses.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include "apue.h"
#include "apue_db.h"

void shoe(FILE*, WINDOW*);
int newrec(WINDOW*, DBHANDLE, FILE*);
int editrec(void);
int datarec(char *, WINDOW*, DBHANDLE);

int
main(int argc, char *argv[]){
	int escape;
	char grabbed;
	SCREEN *screen;
	WINDOW *win;
	FILE *keyfile;
	char key[11];
	DBHANDLE db;
	int display;

	if(argc != 2) return 255;
	
	screen = newterm(NULL, stdin, stdout);
	win = initscr();
	nodelay(win, TRUE);

	if ( (keyfile=fopen("KEYS.TXT", "r+"))==NULL)
		err_sys("keyfile opening failed");
	if((db=db_open(argv[1], O_RDWR, FILE_MODE))==NULL)
		err_sys("db_open failed");
	
	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			if(display==0)display=1;
			else display=0;
		}
		if(grabbed == 'n'){
			display=2;
		}
		if(grabbed == 'e'){
			display=3;
		}	
				/* output rejuncture flip */
		wclear(win);
		if(display==0){
			shoe(keyfile, win);
		} else if (display==2){
			display=newrec(win, db, keyfile);
		} else if (display==3){
			display=editrec();/* both these two needed sig */
		} else {
			datarec(key, win, db);
		}
		wrefresh(win);
	}
	fclose(keyfile);
	db_close(db);
	endwin();
	return 0;
}

void
shoe(FILE *myfile, WINDOW *mywin){
	char buffer[20];
	int index;

	index=0;
	rewind(myfile);
	while( !(feof(myfile)) ){
		fread(buffer, 1, 20, myfile);
		mvwaddnstr(mywin, index, 15, buffer, 20);
		index++;
	}
	return;
}

int
editrec(){
	return 0;
}

int
datarec(char *mykey, WINDOW *mywin, DBHANDLE mydb){
	char data[1024];
	int i;
	
	for(i=0; i<1024; i++)data[i]=0;		
	strncat(data, db_fetch(mydb, mykey), 1000);
	mvwaddnstr(mywin, 0, 0,  data, strlen(data));
	return 0;
}

int
newrec(WINDOW *mywin, DBHANDLE mydb, FILE *keysfile){
	char		data[10][85];
	char		collect[1000];
	char		mychar;
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	char		key[12];
	
	index=0;

	mvwgetnstr(mywin, 15, 20, key, 10);
	fwrite(key, 1, 10, keysfile);

	wclear(mywin);

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		mvwgetnstr(mywin, index, 0, data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(mydb, key, collect, DB_INSERT) != 0)
		err_quit("db_store error for newrec");
	
	return 0;
}
