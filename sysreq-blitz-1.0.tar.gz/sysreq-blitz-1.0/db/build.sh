#!/bin/sh

cc creatdb.c -o creatdb -L. -L../lib -lapue_db -lapue -I. -I../include
cc fetch.c -o fetch -L. -L../lib -lapue_db -lapue -I. -I../include
cc newrec.c -o newrec -L. -L../lib -lapue_db -lapue -I. -I../include
cc editrec.c -o editrec -L. -L../lib -lapue_db -lapue -I. -I../include
rm *.o *.core
