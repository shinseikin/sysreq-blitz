#include <curses.h>
#include <stdio.h>
#include "apue.h"
#include "apue_db.h"

void shoe(void);
void datarec(char *);

int
main(void){
	int escape;
	char grabbed;
	SCREEN *screen;
	WINDOW *win;
	FILE *input;
	FILE *output;
	char key[11];

	screen = newterm(NULL, input, output);
	win = initscr();

	keyok();
	nodelay();

	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			if(display==0)display=1;
			else display=0;
		}
				/* output rejuncture flip */
		if(display==0){
			shoe();
		} else {
			datarec(key);
		}
		wrefresh(win);
	}
	endwin();
	return 0;
}


