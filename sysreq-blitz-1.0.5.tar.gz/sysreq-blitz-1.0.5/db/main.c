#include "blitz.h"

int
main(int argc, char *argv[]){
	int escape;
	char grabbed;
	SCREEN *screen;
	WINDOW *win;
	FILE *keyfile;
	char key[25][11];
	int numkeys;
	int selected;
	DBHANDLE db;
	int display;

	if(argc != 2) return 255;
	
	screen = newterm(NULL, stdin, stdout);
	win = initscr();
	nodelay(win, FALSE);
	display=0;

	if ( (keyfile=fopen("KEYS.TXT", "r+"))==NULL)
		err_sys("keyfile opening failed");
	if((db=db_open(argv[1], O_RDWR, FILE_MODE))==NULL)
		err_sys("db_open failed");
	
	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			if(display==0)display=1;
			else display=0;
		}
		if(grabbed == 'n'){
			display=2;
		}
		if(grabbed == 'e'){
			display=3;
		}
		if(grabbed == 'h'){
			if (selected > 0)
				selected--;
		}
		if(grabbed == 'j'){
			if(selected<numkeys)
				selected++;
		}	
/* there is a stack of keys that need to be traversaled with
h is up j is down */
				/* output rejuncture flip */
		wclear(win);
		if(display==0){
			shoe(win, key, selected, numkeys);
		} else if (display==2){
			newrec(win, db, key, &numkeys);
			display=0;
		} else if (display==3){
			editrec(win, db, key[selected]);
			display=0;
		} else {
			datarec(win, db, key[selected]);
		}
		wrefresh(win);
	}
	fclose(keyfile);
	db_close(db);
	endwin();
	return 0;
}

void
shoe(WINDOW *mywin, char **list, int ledge, int stack){
	int y;

	for (y=0; y<stack; y++){
		if(y==ledge)
			mvwaddnstr(mywin, y, 8, "-->", 3);
		mvwaddnstr(mywin, y, 15, list[y], 11);
	}
	return;
}



int
datarec(WINDOW *mywin, DBHANDLE mydb, char *mykey){
	char data[1024];
	int i;
	
	for(i=0; i<1024; i++)data[i]=0;		
	strncat(data, db_fetch(mydb, mykey), 1000);
	mvwaddnstr(mywin, 0, 0,  data, strlen(data));
	return 0;
}

int
newrec(WINDOW *mywin, DBHANDLE mydb, char **list, int *stack){
	char		data[10][85];
	char		collect[1000];
	char		mychar;
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	char		key[12];	
	
	index=0;

	mvwgetnstr(mywin, 15, 20, key, 10);
	*stack++;
	strncpy(list[*stack], key, 11);
	wclear(mywin);

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		mvwgetnstr(mywin, index, 0, data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(mydb, key, collect, DB_INSERT) != 0)
		err_quit("db_store error for newrec");
	
	return 0;
}


int
editrec(WINDOW* mywin, DBHANDLE mydb, char *mykey){
	char		data[10][85];
	char		collect[1000];
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	
	index=0;

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		mvwgetnstr(mywin, index, 0, data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(mydb, mykey, collect, DB_REPLACE) != 0)
		err_quit("db_store error for newrec");
	
	return 0;
}
