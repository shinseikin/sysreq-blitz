#include <curses.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include "apue.h"
#include "apue_db.h"

void shoe(WINDOW*, char**, int, int); 
int newrec(WINDOW*, DBHANDLE, char**, int*);
int editrec(WINDOW*, DBHANDLE, char*);
int datarec(WINDOW*, DBHANDLE, char*);


/*int loadkeys(void);
int savekeys(void);

struct diskdata {
	storage[25][11]
};
*/
