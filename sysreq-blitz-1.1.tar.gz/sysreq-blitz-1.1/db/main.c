#include "blitz.h"

int
main(int argc, char *argv[]){
	int escape;
	char grabbed;
	SCREEN *screen;
	int selected;
	int display; /* check this */
	struct dat box;

	if(argc != 2) return 255;
	
	screen = newterm(NULL, stdin, stdout);
	box.mywin = initscr();
	nodelay(box.mywin, FALSE);
	display=0;
	selected=0;
	box.tos=0;
	keypad(box.mywin, TRUE);
	
	if((box.mydb=db_open(argv[1], O_RDWR, FILE_MODE))==NULL)
		err_sys("db_open failed");
	
	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			display=1;
		}
		if(grabbed == 'n'){
			display=2;
		}
		if(grabbed == 'e'){
			display=3;
		}
		if(grabbed == 'h'){
			if (selected > 0)
				selected--;
			else selected=(box.tos-1);
		}
		if(grabbed == 'j'){
			if(selected<(box.tos-1))
				selected++;
			else selected=0;
		}	
				/* output rejuncture flip */
		wclear(box.mywin);
		if(display==0){
			shoe(&box, selected);
		} else if (display==1){
			datarec(&box, selected);
			display=0;
		} else if (display==2){
			newrec(&box);
			display=0;
		} else if (display==3){
			editrec(box.mywin, box.mydb, box.keylist[selected]);
			display=0;
		} else {
			display=0;
		}
		wrefresh(box.mywin);
	}
	db_close(box.mydb);
	endwin();
	return 0;
}

int
shoe(struct dat* mydat, int check){
	int y;
	
	wclear(mydat->mywin);
	for (y=0; y<mydat->tos; y++){
		if(y==check)
			mvwaddnstr(mydat->mywin, y, 8, "-->", 3);
		mvwaddnstr(mydat->mywin, y, 15, mydat->keylist[y], 11);
	}
	wrefresh(mydat->mywin);
	return 0;
}



int
datarec(struct dat* mydat, int check){
	mvwprintw(mydat->mywin, 0, 0, "%s", db_fetch(mydat->mydb, mydat->keylist[check]));
	wrefresh(mydat->mywin);
	getch();
	return 0;
}

int
newrec(struct dat* mydat){
	char		data[10][85];
	char		collect[1000];
	char		mychar;
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	char		key[12];	
	
	index=0;

	mvwgetnstr(mydat->mywin, 15, 20, mydat->keylist[mydat->tos], 10);
	wclear(mydat->mywin);

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		mvwgetnstr(mydat->mywin, index, 0, data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(mydat->mydb, mydat->keylist[mydat->tos], collect, DB_INSERT) != 0)
		err_quit("db_store error for newrec");
	mydat->tos++;
	return 0;
}


int
editrec(WINDOW* mywin, DBHANDLE mydb, char *mykey){
	char		data[10][85];
	char		collect[1000];
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	
	index=0;

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		mvwgetnstr(mywin, index, 0, data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(mydb, mykey, collect, DB_REPLACE) != 0)
		err_quit("db_store error for newrec");
	
	return 0;
}
