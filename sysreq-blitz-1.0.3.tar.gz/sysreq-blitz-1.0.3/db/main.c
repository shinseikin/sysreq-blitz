#include <curses.h>
#include <stdio.h>
#include <fcntl.h>
#include <time.h>
#include "apue.h"
#include "apue_db.h"

void shoe(FILE*, WINDOW*);
void newrec(void);
void editrec(void);
void datarec(char *);

int
main(int argc, char *argv[]){
	int escape;
	char grabbed;
	SCREEN *screen;
	WINDOW *win;
	FILE *keyfile;
	char key[11];
	DBHANDLE db;
	int display;

	if(argc != 2) return 255;
	
	screen = newterm(NULL, stdin, stdout);
	win = initscr();
	nodelay(win, TRUE);

	if ( (keyfile=fopen("KEYS.TXT", "r+"))==NULL)
		err_sys("keyfile opening failed");
	if((db=db_open(argv[1], O_RDWR, FILE_MODE))==NULL)
		err_sys("db_open failed");
	
	while (!escape){
		grabbed=getch(); /* input and input processing */
		if(grabbed == 'q')escape=255;
		if(grabbed == ' '){
			if(display==0)display=1;
			else display=0;
			if(display=2)display=0;
			if(display=3)display=0;
		}
		if(grabbed == 'n'){
			display=2;
		}
		if(grabbed == 'e'){
			display=3;
		}	
				/* output rejuncture flip */
		wclear(win);
		if(display==0){
			shoe(keyfile, win);
		} else if (display==2){
			newrec();
		} else if (display==3){
			editrec();
		} else {
			datarec(key);
		}
		wrefresh(win);
	}
	fclose(keyfile);
	db_close(db);
	endwin();
	return 0;
}

void
shoe(FILE *myfile, WINDOW *mywin){
	char buffer[20];
	int index;

	index=0;
	rewind(myfile);
	while( !(feof(myfile)) ){
		fread(buffer, 1, 20, myfile);
		mvwaddnstr(mywin, index, 15, buffer, 20);
		index++;
	}
	return;
}

void
datarec(char *rec){
	return;
}

void
newrec(){
	return;
}

void
editrec(){
	return;
}
